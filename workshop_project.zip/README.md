## Welcome the LLAP Workshop!

This is an RStudio project.  To use it do the following:

1. Open RStudio 
2. Click File - Open Project 
3. Navigate to this folder and click the .Rproj file

The only files you need for the workshop are .Rmd notebook files.  You can run
the code therein as we go along.

To get started run the RunThis.R file.

